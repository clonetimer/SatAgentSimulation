"""Deterministic script exporters for TaskSpec execution.

The exporter provides a safe product-facing meaning of "script generation": it
writes thin, auditable wrapper code that executes an already validated TaskSpec
through the trusted sat_sim pipeline. It does not ask an LLM to write arbitrary
Python.
"""
from __future__ import annotations
from utils.runtime_diagnostics import DiagnosticCategory, record_runtime_diagnostic

import json
import copy
import hashlib
import pprint
import shlex
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Any, Literal, Mapping


ScriptKind = Literal["python", "shell", "capability-python", "assembly-python"]


@dataclass(frozen=True)
class ScriptExportResult:
    kind: ScriptKind
    output_path: Path
    spec_path: Path
    output_root: str | None = None

    def to_dict(self) -> dict[str, str | None]:
        payload = asdict(self)
        payload["output_path"] = str(self.output_path)
        payload["spec_path"] = str(self.spec_path)
        return payload


def _quote_python_path(path: Path) -> str:
    return repr(str(path))


def exported_task_field_fingerprints(spec: Mapping[str, Any]) -> dict[str, str]:
    """Remember field values without embedding a second editable TaskSpec.

    These are edit-detection hints in a trusted local script, not signatures or
    an authorization boundary. Lists are atomic fields, as in TaskSpec patches.
    """
    from .task_models import canonicalize_task_spec
    def walk(value: Any, path: str = "") -> dict[str, str]:
        if isinstance(value, Mapping):
            result: dict[str, str] = {}
            for key, child in value.items():
                if not path and key in {"provenance", "schema_version"}:
                    continue
                result.update(walk(child, f"{path}.{key}" if path else str(key)))
            return result
        encoded = json.dumps(value, sort_keys=True, ensure_ascii=False, separators=(",", ":"), allow_nan=False)
        return {path: hashlib.sha256(encoded.encode("utf-8")).hexdigest()}
    return walk(canonicalize_task_spec(spec))


def _set_export_path(data: dict[str, Any], path: str, value: Any) -> None:
    parts = path.split(".")
    for part in parts[:-1]:
        if not isinstance(data.get(part), dict):
            data[part] = {}
        data = data[part]
    data[parts[-1]] = value


def _merge_projection_changes(original: Any, before: Any, after: Any) -> Any:
    """Apply only edited projection fields; do not re-migrate public history."""
    if isinstance(before, Mapping) and isinstance(after, Mapping):
        result = copy.deepcopy(dict(original)) if isinstance(original, Mapping) else {}
        for key in set(before) | set(after):
            if key not in after:
                result.pop(key, None)
            elif key not in before:
                result[key] = copy.deepcopy(after[key])
            elif before[key] != after[key]:
                result[key] = _merge_projection_changes(result.get(key), before[key], after[key])
        return result
    return copy.deepcopy(after)


def build_exported_task_spec(
    task_spec: Mapping[str, Any], *, duration_s: float | None = None,
    sample_s: float | None = None, output_root: str | None = None,
    overrides: Any = (), field_sha256: Mapping[str, str] | None = None,
) -> dict[str, Any]:
    """Preserve canonical identity, adapting explicit legacy CLI paths locally."""
    from .task_models import canonicalize_task_spec, to_runtime_task_spec, SimulationSpec, OutputSpec
    from .taskspec_alignment import align_task_spec_to_source

    canonical = canonicalize_task_spec(task_spec)
    derived_paths: set[str] = set()
    for path, value in (("simulation.duration_s", duration_s), ("simulation.sample_s", sample_s), ("outputs.output_root", output_root)):
        if value is not None:
            _set_export_path(canonical, path, str(value) if path == "outputs.output_root" else float(value))
    for item in overrides or ():
        if "=" not in item:
            raise SystemExit(f"--set expects dotted.path=value, got {item!r}")
        path, raw = item.split("=", 1)
        path = path.strip()
        if not path:
            raise SystemExit(f"--set path cannot be empty: {item!r}")
        try:
            value = json.loads(raw)
        except (ValueError, TypeError):
            value = raw
        parts = path.split(".")
        head, second = parts[0], parts[1] if len(parts) > 1 else ""
        public_path = (
            head in {"task", "model", "events", "mission", "assurance", "provenance"}
            or (head == "metadata" and second not in {"task_name", "parameter_profile", "claim_level", "validation_profile", "fidelity_level", "parameter_registry_id", "parameter_registry_hash"})
            or (head == "parameters" and second in {"values", "profile", "overrides", "registry_id", "registry_hash"})
            or (head == "simulation" and second in SimulationSpec.model_fields)
            or (head == "outputs" and second in OutputSpec.model_fields)
        )
        if public_path:
            _set_export_path(canonical, path, value)
            continue
        # Compatibility examples: parameters.X, task_id, simulation.seed,
        # outputs.record_fields and modifiers.faults keep their 0.1 meanings.
        before_runtime = to_runtime_task_spec(canonical)
        edited = copy.deepcopy(before_runtime)
        _set_export_path(edited, path, value)
        aligned = align_task_spec_to_source(edited, fill_defaults=True)
        if not aligned.repairs:
            previous = edited.get("metadata", {})
            if "taskspec_src_alignment" in previous:
                aligned.task_spec["metadata"]["taskspec_src_alignment"] = copy.deepcopy(previous["taskspec_src_alignment"])
            else:
                aligned.task_spec.get("metadata", {}).pop("taskspec_src_alignment", None)
        for default_path in aligned.normalized_defaults:
            if default_path.startswith("parameters."):
                suffix = default_path.removeprefix("parameters.")
                derived_paths.update({"parameters.values." + suffix, "model.config." + suffix})
            else:
                derived_paths.add(default_path)
        derived_paths.update({"metadata.normalized_defaults", "metadata.repair_log", "metadata.taskspec_src_alignment"})
        before_projection = canonicalize_task_spec(before_runtime)
        after_projection = canonicalize_task_spec(aligned.task_spec)
        # Migration mirrors runtime parameters into model.config; that mirror
        # must not become a second public edit when values is authoritative.
        after_projection["model"]["config"] = before_projection["model"]["config"]
        if not canonical.get("parameters", {}).get("values") and before_projection["parameters"]["values"]:
            canonical["parameters"]["values"] = copy.deepcopy(before_projection["parameters"]["values"])
            derived_paths.update("parameters.values." + key for key in canonical["parameters"]["values"])
        canonical = _merge_projection_changes(canonical, before_projection, after_projection)
    canonical = canonicalize_task_spec(canonical)
    if field_sha256 is not None:
        current = exported_task_field_fingerprints(canonical)
        provenance = canonical.setdefault("provenance", {}).setdefault("fields", {})
        for path in sorted(set(field_sha256) | set(current)):
            if field_sha256.get(path) == current.get(path):
                continue
            derived = any(path == prefix or path.startswith(prefix + ".") for prefix in derived_paths)
            entry = {
                "source": "resolver_derived" if derived else "user_explicit",
                "evidence": f"Generated script {'normalization' if derived else 'local override'}: {path}; value SHA256 {field_sha256.get(path, 'absent')} -> {current.get(path, 'absent')}",
                "note": "Supersedes prior evidence for the changed value; unchanged field provenance is retained.",
            }
            for previous in list(provenance):
                if previous.startswith(path + "."):
                    del provenance[previous]
                elif path.startswith(previous + "."):
                    provenance[previous] = dict(entry)
            provenance[path] = entry
    return canonicalize_task_spec(canonical)


def _prepare_export_payload(spec: Mapping[str, Any], contract: Mapping[str, Any], output_root: str | Path | None, *, assembly: bool = False) -> dict[str, Any]:
    from .task_models import canonicalize_task_spec, is_canonical_task_spec, to_runtime_task_spec
    if is_canonical_task_spec(spec):
        canonical = canonicalize_task_spec(spec)
    else:
        from .taskspec_alignment import align_task_spec_to_source
        payload = align_task_spec_to_source(to_runtime_task_spec(spec), capability=contract, fill_defaults=True).task_spec
        try:
            from .taskspec_pruning import prune_task_spec_for_capability
            payload = prune_task_spec_for_capability(payload).task_spec
        except Exception as exc:
            record_runtime_diagnostic(
                code="ASSEMBLY_SCRIPT_EXPORT_PRUNING_FALLBACK" if assembly else "SCRIPT_EXPORT_PRUNING_FALLBACK",
                category=DiagnosticCategory.AGENT_NORMALIZATION_FALLBACK,
                location="src/sat_sim/script_exporter.py:_prepare_export_payload", exception=exc, strict=False,
            )
        canonical = canonicalize_task_spec(payload)
    return build_exported_task_spec(canonical, output_root=str(output_root) if output_root is not None else None,
        field_sha256=exported_task_field_fingerprints(canonical))


def export_python_runner(spec_path: str | Path, output_path: str | Path, *, output_root: str | Path | None = None) -> ScriptExportResult:
    spec = Path(spec_path)
    out = Path(output_path)
    out.parent.mkdir(parents=True, exist_ok=True)
    output_root_expr = repr(str(output_root)) if output_root is not None else "None"
    from .task_spec import load_task_spec
    field_hashes = exported_task_field_fingerprints(load_task_spec(spec).data) if spec.is_file() else None
    field_hash_literal = pprint.pformat(field_hashes, width=100)
    content = f'''#!/usr/bin/env python3
"""Generated TaskSpec runner.

This file is deterministic wrapper code generated by sat_sim.script_exporter.
Edit the TaskSpec YAML/JSON, not this wrapper, when changing simulation physics
or scenario parameters.
"""

import json
import sys
from pathlib import Path

from sat_sim.task_spec import load_task_spec
from sat_sim.task_validator import validate_task_spec
from sat_sim.task_compiler import compile_task_spec
from sat_sim.execution_planner import plan_task_spec, attach_plan_metadata, validate_execution_plan
from sat_sim.script_exporter import build_exported_task_spec
from sat_sim.validation_outcome import evaluate_validation_outcome
from sat_sim.unified_execution import execute_compiled_task

SPEC_PATH = Path({_quote_python_path(spec)})
OUTPUT_ROOT = {output_root_expr}
EXPORTED_FIELD_SHA256 = {field_hash_literal}


def main() -> int:
    for stream in (sys.stdout, sys.stderr):
        if hasattr(stream, "reconfigure"):
            stream.reconfigure(encoding="utf-8")
    doc = load_task_spec(SPEC_PATH)
    canonical = build_exported_task_spec(doc.data, output_root=OUTPUT_ROOT, field_sha256=EXPORTED_FIELD_SHA256)
    validation = validate_task_spec(canonical)
    validation.raise_for_errors()
    compiled = compile_task_spec(canonical, validate=False)
    planning = plan_task_spec(canonical)
    if not planning.ok or planning.resolved_spec is None or planning.execution_plan is None:
        print(json.dumps({{"ok": False, "planning": planning.to_dict()}}, indent=2, ensure_ascii=False))
        return 1
    plan_validation = validate_execution_plan(planning.execution_plan, planning.resolved_spec)
    if not plan_validation.ok:
        print(json.dumps({{"ok": False, "planning": planning.to_dict(),
            "plan_validation": plan_validation.to_dict()}}, indent=2, ensure_ascii=False))
        return 1
    compiled = attach_plan_metadata(compiled, planning)
    result = execute_compiled_task(compiled, task_spec=canonical, execution_plan_sha256=planning.execution_plan.plan_sha256, output_root=OUTPUT_ROOT or compiled.outputs.get("output_root"), write_dataset=True)
    outcome = evaluate_validation_outcome(spec=canonical, resolved=planning.resolved_spec,
        summary=result.summary, trace_rows=result.trace_rows)
    ok = outcome.result.value == "PASS"
    print(json.dumps({{"ok": ok, "task_id": compiled.task_id, "summary": result.summary,
        "execution_plan_sha256": planning.execution_plan.plan_sha256,
        "resolved_spec_sha256": planning.resolved_spec.resolved_spec_sha256,
        "validation_outcome": outcome.model_dump(mode="json"),
        "dataset": result.dataset.to_dict() if result.dataset else None}}, indent=2, ensure_ascii=False))
    return 0 if ok else 1


if __name__ == "__main__":
    raise SystemExit(main())
'''
    out.write_text(content, encoding="utf-8")
    try:
        out.chmod(out.stat().st_mode | 0o111)
    except Exception as exc:
        record_runtime_diagnostic(
            code='SCRIPT_EXECUTABLE_PERMISSION_UPDATE_FAILED',
            category=DiagnosticCategory.BEST_EFFORT_CLEANUP,
            location='src/sat_sim/script_exporter.py:export_python_runner:01',
            exception=exc,
            strict=False,
        )
    return ScriptExportResult(kind="python", output_path=out, spec_path=spec, output_root=str(output_root) if output_root is not None else None)


def export_shell_runner(spec_path: str | Path, output_path: str | Path, *, output_root: str | Path | None = None) -> ScriptExportResult:
    spec = Path(spec_path)
    out = Path(output_path)
    out.parent.mkdir(parents=True, exist_ok=True)
    cmd = ["sat-sim", "run", str(spec)]
    if output_root is not None:
        cmd += ["--output", str(output_root)]
    content = "#!/usr/bin/env bash\nset -euo pipefail\n" + " ".join(shlex.quote(part) for part in cmd) + "\n"
    out.write_text(content, encoding="utf-8")
    try:
        out.chmod(out.stat().st_mode | 0o111)
    except Exception as exc:
        record_runtime_diagnostic(
            code='SCRIPT_EXECUTABLE_PERMISSION_UPDATE_FAILED',
            category=DiagnosticCategory.BEST_EFFORT_CLEANUP,
            location='src/sat_sim/script_exporter.py:export_shell_runner:01',
            exception=exc,
            strict=False,
        )
    return ScriptExportResult(kind="shell", output_path=out, spec_path=spec, output_root=str(output_root) if output_root is not None else None)


def _source_binding_comment(source_binding: Mapping[str, Any]) -> str:
    mode = source_binding.get("mode", "unknown")
    primary = source_binding.get("primary_module", "")
    public_api = source_binding.get("public_api") or []
    if isinstance(public_api, list):
        public_api_text = ", ".join(str(x) for x in public_api[:8])
    else:
        public_api_text = str(public_api)
    return f"# Source binding: mode={mode}; primary_module={primary}; public_api={public_api_text}"


def _generate_capability_python_script(
    payload: Mapping[str, Any],
    contract_data: Mapping[str, Any],
    *,
    assembly_graph: Mapping[str, Any] | None = None,
) -> str:
    from .source_native import public_source_binding_payload

    capability_id = str(contract_data.get("capability_id", payload.get("capability_id", "")))
    source_binding = public_source_binding_payload(contract_data)
    from .task_models import canonicalize_task_spec
    payload = canonicalize_task_spec(payload)
    task_spec_literal = pprint.pformat(dict(payload), width=100, sort_dicts=False)
    field_hash_literal = pprint.pformat(exported_task_field_fingerprints(payload), width=100)
    source_binding_literal = pprint.pformat(dict(source_binding), width=100, sort_dicts=False)
    source_comment = _source_binding_comment(source_binding)
    assembly_literal = pprint.pformat(dict(assembly_graph), width=100, sort_dicts=False) if assembly_graph is not None else "None"
    assembly_import = (
        "from sat_sim.assembly_graph import validate_assembly_graph, validate_assembly_task_spec_binding\n"
        if assembly_graph is not None else ""
    )
    assembly_validation = (
        "    assembly_validation = validate_assembly_graph(ASSEMBLY_GRAPH, expected_parent_capability_id=CAPABILITY_ID)\n"
        "    if not assembly_validation.ok:\n"
        "        raise SystemExit(json.dumps({\"ok\": False, \"assembly_validation\": assembly_validation.to_dict()}, indent=2, ensure_ascii=False))\n"
        if assembly_graph is not None else ""
    )
    assembly_task_binding = (
        "    assembly_task_binding = validate_assembly_task_spec_binding(task_spec, ASSEMBLY_GRAPH, validation=assembly_validation)\n"
        "    if not assembly_task_binding.get(\"ok\"):\n"
        "        raise SystemExit(json.dumps({\"ok\": False, \"assembly_task_binding\": assembly_task_binding}, indent=2, ensure_ascii=False))\n"
        if assembly_graph is not None else ""
    )
    default_output = str((payload.get("outputs") if isinstance(payload.get("outputs"), Mapping) else {}).get("output_root") or payload.get("task_id") or "capability_output")
    return f'''#!/usr/bin/env python3
"""Generated capability-python simulation script.

This script is deterministic code generated by sat_sim.script_exporter.  It uses
the same unified execution path as product TaskSpec runs; it is not authored by
an LLM and does not import capability adapter class paths directly.
"""

import argparse
import json
import sys
from typing import Any

from sat_sim.task_compiler import compile_task_spec
from sat_sim.task_models import canonicalize_task_spec
from sat_sim.execution_planner import plan_task_spec, attach_plan_metadata, validate_execution_plan
from sat_sim.validation_outcome import evaluate_validation_outcome
from sat_sim.script_exporter import build_exported_task_spec
from sat_sim.unified_execution import execute_compiled_task
{assembly_import}
CAPABILITY_ID = {capability_id!r}
SOURCE_BINDING = {source_binding_literal}
ASSEMBLY_GRAPH = {assembly_literal}
{source_comment}

# ---------------------------------------------------------------------------
# User-editable TaskSpec parameter section
# ---------------------------------------------------------------------------
# Edit TASK_SPEC values directly, or override them at runtime with:
#   --duration-s 3600 --sample-s 30 --output-root datasets/my_run
#   --set parameters.values.capacity_bits=8000000  (canonical path)
#   --set parameters.capacity_bits=8000000         (legacy runtime alias)
#
# Edit the public canonical TASK_SPEC, including parameters.values and events.
# Legacy --set modifiers.* paths remain accepted; modifiers are not standalone
# runnable capabilities. Example:
#   modifiers.faults=[{{"target":"eps.battery","fault_type":"capacity_drop","onset_time_s":120,"severity":0.2}}]
TASK_SPEC = {task_spec_literal}
# Generated edit-detection hints, not signatures or an authorization boundary.
EXPORTED_FIELD_SHA256 = {field_hash_literal}


# ---------------------------------------------------------------------------
# Runtime helpers
# ---------------------------------------------------------------------------
def build_task_spec(args: argparse.Namespace) -> dict[str, Any]:
    return build_exported_task_spec(TASK_SPEC, duration_s=args.duration_s,
        sample_s=args.sample_s, output_root=args.output_root, overrides=args.set,
        field_sha256=EXPORTED_FIELD_SHA256)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=f"Run {{CAPABILITY_ID}} capability simulation.")
    parser.add_argument("--output-root", default={default_output!r}, help="dataset output directory")
    parser.add_argument("--duration-s", type=float, help="override simulation.duration_s")
    parser.add_argument("--sample-s", type=float, help="override simulation.sample_s")
    parser.add_argument("--set", action="append", default=[], metavar="PATH=VALUE", help="override any TaskSpec dotted path; VALUE is parsed as JSON when possible")
    parser.add_argument("--show-task-spec", action="store_true", help="print normalized TaskSpec before running")
    return parser.parse_args()


def main() -> int:
    for stream in (sys.stdout, sys.stderr):
        if hasattr(stream, "reconfigure"):
            stream.reconfigure(encoding="utf-8")
{assembly_validation}    args = parse_args()
    task_spec = build_task_spec(args)
{assembly_task_binding}    if args.show_task_spec:
        print(json.dumps(task_spec, indent=2, ensure_ascii=False))
    compiled = compile_task_spec(task_spec, validate=True)
    canonical = canonicalize_task_spec(task_spec)
    planning = plan_task_spec(canonical)
    if not planning.ok or planning.resolved_spec is None or planning.execution_plan is None:
        print(json.dumps({{"ok": False, "planning": planning.to_dict()}}, indent=2, ensure_ascii=False))
        return 1
    plan_validation = validate_execution_plan(planning.execution_plan, planning.resolved_spec)
    if not plan_validation.ok:
        print(json.dumps({{"ok": False, "planning": planning.to_dict(),
            "plan_validation": plan_validation.to_dict()}}, indent=2, ensure_ascii=False))
        return 1
    compiled = attach_plan_metadata(compiled, planning)
    output_root = task_spec.get("outputs", {{}}).get("output_root") or args.output_root or {default_output!r}
    result = execute_compiled_task(
        compiled,
        task_spec=task_spec,
        execution_plan_sha256=planning.execution_plan.plan_sha256,
        output_root=output_root,
        write_dataset=True,
    )
    outcome = evaluate_validation_outcome(spec=canonical, resolved=planning.resolved_spec,
        summary=result.summary, trace_rows=result.trace_rows)
    ok = outcome.result.value == "PASS"
    payload = {{
        "ok": ok,
        "capability_id": CAPABILITY_ID,
        "execution_plan_sha256": planning.execution_plan.plan_sha256,
        "resolved_spec_sha256": planning.resolved_spec.resolved_spec_sha256,
        "summary": result.summary,
        "validation_outcome": outcome.model_dump(mode="json"),
        "dataset": result.dataset.to_dict() if result.dataset else None,
    }}
    print(json.dumps(payload, indent=2, ensure_ascii=False))
    return 0 if payload["ok"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
'''


def export_capability_python_runner(spec_path: str | Path, output_path: str | Path, *, output_root: str | Path | None = None) -> ScriptExportResult:
    """Export readable adapter-backed Python code for a capability TaskSpec.

    This path still requires ``capability_id`` and still executes the explicit
    capability adapter. S6 centralizes the wrapper template so every exported
    script has the same parameter block, argparse overrides, and source-binding
    comments.
    """

    from .capability_registry import get_capability
    from .task_spec import load_task_spec
    from .task_models import to_runtime_task_spec

    spec = Path(spec_path)
    out = Path(output_path)
    doc = load_task_spec(spec)
    payload = to_runtime_task_spec(doc.data)
    capability_id = payload.get("capability_id")
    if not isinstance(capability_id, str) or not capability_id.strip():
        raise ValueError("capability-python export requires TaskSpec capability_id")
    contract = get_capability(capability_id)
    payload = _prepare_export_payload(doc.data, contract.data, output_root, assembly=False)
    content = _generate_capability_python_script(payload, contract.data)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(content, encoding="utf-8")
    try:
        out.chmod(out.stat().st_mode | 0o111)
    except Exception as exc:
        record_runtime_diagnostic(
            code='SCRIPT_EXECUTABLE_PERMISSION_UPDATE_FAILED',
            category=DiagnosticCategory.BEST_EFFORT_CLEANUP,
            location='src/sat_sim/script_exporter.py:export_capability_python_runner:02',
            exception=exc,
            strict=False,
        )
    return ScriptExportResult(kind="capability-python", output_path=out, spec_path=spec, output_root=str(output_root) if output_root is not None else None)


def export_assembly_python_runner(
    spec_path: str | Path,
    output_path: str | Path,
    *,
    assembly_graph: Mapping[str, Any],
    output_root: str | Path | None = None,
) -> ScriptExportResult:
    """Export deterministic executable code with a registered module assembly.

    The assembly is embedded as data and revalidated at runtime.  Execution is
    still owned by the registered parent Capability adapter; no arbitrary class
    path or Python source is accepted from the graph.
    """
    from .assembly_graph import validate_assembly_graph, validate_assembly_task_spec_binding
    from .capability_registry import get_capability
    from .task_spec import load_task_spec
    from .task_models import to_runtime_task_spec

    spec = Path(spec_path)
    out = Path(output_path)
    doc = load_task_spec(spec)
    payload = to_runtime_task_spec(doc.data)
    capability_id = payload.get("capability_id")
    if not isinstance(capability_id, str) or not capability_id.strip():
        raise ValueError("assembly-python export requires TaskSpec capability_id")
    assembly_validation = validate_assembly_graph(
        assembly_graph,
        expected_parent_capability_id=capability_id,
        require_all_bindings=True,
    )
    if not assembly_validation.ok:
        messages = "; ".join(item.message for item in assembly_validation.errors[:8])
        raise ValueError(f"assembly graph validation failed: {messages}")
    assembly_task_binding = validate_assembly_task_spec_binding(
        doc.data,
        assembly_graph,
        validation=assembly_validation,
    )
    if not assembly_task_binding.get("ok"):
        messages = "; ".join(str(item.get("message") or item.get("code")) for item in assembly_task_binding.get("errors", [])[:8])
        raise ValueError(f"assembly TaskSpec binding validation failed: {messages}")
    contract = get_capability(capability_id)
    payload = _prepare_export_payload(doc.data, contract.data, output_root, assembly=True)
    # Visual observer annotations (for example Scope probes) are project/UI data,
    # not part of the physical assembly runtime.  Validate the submitted graph
    # above, but deliberately omit observers from the generated runner so adding
    # or moving a Scope cannot change executable simulation code.
    runtime_assembly_graph = dict(assembly_graph)
    runtime_assembly_graph.pop("scopes", None)
    content = _generate_capability_python_script(payload, contract.data, assembly_graph=runtime_assembly_graph)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(content, encoding="utf-8")
    try:
        out.chmod(out.stat().st_mode | 0o111)
    except Exception as exc:
        record_runtime_diagnostic(
            code="SCRIPT_EXECUTABLE_PERMISSION_UPDATE_FAILED",
            category=DiagnosticCategory.BEST_EFFORT_CLEANUP,
            location="src/sat_sim/script_exporter.py:export_assembly_python_runner:02",
            exception=exc,
            strict=False,
        )
    return ScriptExportResult(kind="assembly-python", output_path=out, spec_path=spec, output_root=str(output_root) if output_root is not None else None)


def export_runner_script(spec_path: str | Path, output_path: str | Path, *, kind: ScriptKind = "python", output_root: str | Path | None = None) -> ScriptExportResult:
    if kind == "python":
        return export_python_runner(spec_path, output_path, output_root=output_root)
    if kind == "shell":
        return export_shell_runner(spec_path, output_path, output_root=output_root)
    if kind == "capability-python":
        return export_capability_python_runner(spec_path, output_path, output_root=output_root)
    if kind == "assembly-python":
        raise ValueError("assembly-python export requires export_assembly_python_runner(..., assembly_graph=...)")
    raise ValueError(f"unsupported script kind: {kind!r}")


__all__ = [
    "ScriptExportResult",
    "ScriptKind",
    "exported_task_field_fingerprints",
    "build_exported_task_spec",
    "export_python_runner",
    "export_shell_runner",
    "export_capability_python_runner",
    "export_assembly_python_runner",
    "export_runner_script",
]
