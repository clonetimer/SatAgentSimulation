"""Run from detached source root with workspace Python: python ../probe.py mode."""
import sys, json, csv, gzip, hashlib, subprocess
from pathlib import Path
import numpy as np
root=Path.cwd()
sys.path.insert(0,str(root/'src'))
out=root.parent
mode=sys.argv[1]
assert mode in ('ledger','heater_off','zero_rate','zero_rate_aligned')
if mode in ('zero_rate','zero_rate_aligned'):
    import importlib.util
    name='sat_sim.bsk_engine.unified_native'
    spec=importlib.util.find_spec(name)
    mod=importlib.util.module_from_spec(spec)
    sys.modules[name]=mod
    s=Path(spec.origin).read_text(encoding='utf-8')
    old='sc.hub.omega_BN_BInit = [0.01, -0.004, 0.002]'
    assert s.count(old)==1
    exec(compile(s.replace(old,'sc.hub.omega_BN_BInit = [0., 0., 0.]'),spec.origin,'exec'),mod.__dict__)
from subsystems.thermal.thermal_network import ThermalNode
from sat_sim.capability_registry import get_adapter_for_capability
from sat_sim.task_compiler import compile_task_spec
from sat_sim.unified_execution import build_execution_request
energy=np.zeros(4)
duration=0.
original=ThermalNode.UpdateState
def observe(self,t):
    global duration
    if self.name!='battery': return original(self,t)
    dt=0 if self._last_ns is None else (t-self._last_ns)*1e-9
    terms=[self._conduction_in_w-self._conduction_out_w,self._solar_heat_w,self._radiation_heat_w]
    original(self,t)
    energy[:]+=np.array([*terms,self.last_heat_input_w])*dt
    duration+=dt
ThermalNode.UpdateState=observe
task=json.loads((out/'baseline/baseline_task_spec.json').read_text(encoding='utf-8'))
if mode=='zero_rate_aligned': task['parameters']['values']['initial_pointing_error_deg']=0.0
if mode=='heater_off': task['parameters']['values']['battery_heater_power_w']=0.
req=build_execution_request(compile_task_spec(task),task)
run=get_adapter_for_capability(req.capability_id).run(req.metadata.get('resolved_runtime_task_spec',task))
keys=['time_s','thermal.battery_temp_c','eps.loads.battery_thermostat_power_w',*['attitude.truth.omega_BN_B_'+a for a in 'xyz']]
a=np.array([[r[k] for k in keys] for r in run.trace_rows])
assert len(a)==11801 and np.isfinite(a).all()
with gzip.open(out/(mode+'.csv.gz'),'wt',newline='') as f:
    wr=csv.writer(f);wr.writerow(keys);wr.writerows(a)
temp=a[:,1]; rates=np.rad2deg(a[:,3:])
result=dict(mode=mode,commit=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),count=len(a),mean=temp.mean(),std=temp.std(),start=temp[0],end=temp[-1],slope=np.polyfit(a[:,0],temp,1)[0]*3600,heater_active_fraction=(a[:,2]>0).mean(),peak=np.abs(rates).max(0).tolist(),peak_time=a[np.abs(rates).argmax(0),0].tolist(),integrated_duration=duration,mean_power_W=dict(zip(['conduction','solar','radiation','input_including_internal'],energy/duration)),residual_J=float(energy.sum()-8000*(temp[-1]-temp[0])))
(out/(mode+'.json')).write_text(json.dumps(result,indent=2))
print(result)

