"""ADCS actuator contracts."""
