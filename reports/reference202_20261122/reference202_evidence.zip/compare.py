from pathlib import Path
import json,csv,gzip,math,hashlib,statistics
p=Path(__file__).resolve().parent
def rows(name):
    with gzip.open(p/name,'rt') as f:return list(csv.DictReader(f))
base=rows('baseline/model_telemetry.csv.gz')
led=rows('ledger.csv.gz')
assert len(base)==len(led)==11801
keys=['time_s','thermal.battery_temp_c',*['attitude.truth.omega_BN_B_'+a for a in 'xyz']]
delta={k:max(abs(float(x[k])-float(y[k])) for x,y in zip(base,led)) for k in keys}
assert max(delta.values())<1e-9,delta
a=[float(r['thermal.battery_temp_c']) for r in led]
t=[float(r['time_s']) for r in led]
fit=statistics.linear_regression(t,a)
detrended=statistics.pstdev(v-fit.slope*s for v,s in zip(a,t))
heater=[float(r['eps.loads.battery_thermostat_power_w']) for r in led]
j=next(i for i,v in enumerate(heater) if v>0)
receipt=dict(max_delta_observer_vs_baseline=delta,first_heater_electrical_on_s=t[j],temperature_at_first_on_C=a[j],std_after_linear_detrend_diagnostic_only=detrended,linear_trend_variance_fraction=1-(detrended/statistics.pstdev(a))**2)
for name in ['heater_off','zero_rate','zero_rate_aligned','ledger']:
    data=json.loads((p/(name+'.json')).read_text())
    assert abs(data['residual_J'])<1 and abs(data['integrated_duration']-3540)<1e-6
    receipt[name]=data
(p/'comparison.json').write_text(json.dumps(receipt,indent=2))
for path in sorted(p.glob('*.csv.gz')):print(path.name,hashlib.sha256(path.read_bytes()).hexdigest())

