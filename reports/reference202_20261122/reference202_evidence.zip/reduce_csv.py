"""Independent CSV reduction. Run from the detached source root."""
import csv,gzip,hashlib,json,math,statistics
from pathlib import Path
out=Path(__file__).resolve().parent
def read(path):
    with gzip.open(path,'rt') as f: return list(csv.DictReader(f))
def lines(rows,k): return [float(r[k]) for r in rows]
f=out/'baseline/model_telemetry.csv.gz'
rows=read(f)
old=read(out/'source/reports/external_reference_alignment/model_telemetry.csv.gz')
t=lines(rows,'time_s')
assert len(t)==11801 and all(abs(v-i*.3)<1e-8 for i,v in enumerate(t))
temp=lines(rows,'thermal.battery_temp_c')
avg=statistics.mean(temp); sd=statistics.pstdev(temp)
def timeseries(a):
    return dict(start=a[0],end=a[-1],mean=statistics.mean(a),std=statistics.pstdev(a))
result=dict(sha256=hashlib.sha256(f.read_bytes()).hexdigest(),grid=[t[0],t[-1],.3,len(t)],battery=timeseries(temp),last600=timeseries(temp[-2001:]),slope_c_per_h=statistics.linear_regression(t,temp).slope*3600,N_mean=[abs(avg-v)/.5 for v in (14.32,15.02)],N_std=[abs(sd-v)/.15 for v in (.86,.68)],axes={},old_max_abs_sample_delta={})
for axis in 'xyz':
    k='attitude.truth.omega_BN_B_'+axis
    a=[math.degrees(x) for x in lines(rows,k)]
    idx=max(range(len(a)),key=lambda i:abs(a[i]))
    excess=[ti for ti,v in zip(t,a) if abs(v)>.1045]
    result['axes'][axis]=dict(peak_signed=a[idx],peak_abs=abs(a[idx]),peak_time=t[idx],N=abs(abs(a[idx])-.095)/.0095,count_above_upper=len(excess),last_above_upper=excess[-1] if excess else None)
for k in ['time_s','thermal.battery_temp_c',*['attitude.truth.omega_BN_B_'+a for a in 'xyz']]:
    result['old_max_abs_sample_delta'][k]=max(abs(x-y) for x,y in zip(lines(rows,k),lines(old,k),strict=True))
(out/'independent.json').write_text(json.dumps(result,indent=2))
print(json.dumps(result,indent=2))
